/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgClasses;

import java.util.Date;

/**
 *
 * @author jota
 */
public class clsPerson {

    private String name1;
    private String name2;
    private String lastname1;
    private String lastname2;
    private Date birthdate;
    private String identifier;
    private String genre;
    private String phone;
    private String email;
    private long salary;
    private String identifierType;

    public clsPerson() {
    }

    public clsPerson(String name1, String name2, String lastname1, String lastname2, Date birthdate, String identifier, String genre, String phone, String email, long salary, String identifierType) {
        this.name1 = name1;
        this.name2 = name2;
        this.lastname1 = lastname1;
        this.lastname2 = lastname2;
        this.birthdate = birthdate;
        this.identifier = identifier;
        this.genre = genre;
        this.phone = phone;
        this.email = email;
        this.salary = salary;
        this.identifierType = identifierType;
    }

    public double CalcularImpuestos() {
        // Cuando el salario es menor a 1 millón
        if (this.getSalary() <= 1000000) {
            return this.getSalary() * 0.01;
        }
        
        // Cuando el salario es mayor a 2 millones y medio
        if (this.getSalary() >= 2500000) {
            return this.getSalary() * 0.025;
        }
        
        // Cuando el salario está entre 1 millon y dos millones y medio
        return this.getSalary() * 0.05;

    }

    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }

    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }

    /**
     * @return the name2
     */
    public String getName2() {
        return name2;
    }

    /**
     * @param name2 the name2 to set
     */
    public void setName2(String name2) {
        this.name2 = name2;
    }

    /**
     * @return the lastname1
     */
    public String getLastname1() {
        return lastname1;
    }

    /**
     * @param lastname1 the lastname1 to set
     */
    public void setLastname1(String lastname1) {
        this.lastname1 = lastname1;
    }

    /**
     * @return the lastname2
     */
    public String getLastname2() {
        return lastname2;
    }

    /**
     * @param lastname2 the lastname2 to set
     */
    public void setLastname2(String lastname2) {
        this.lastname2 = lastname2;
    }

    /**
     * @return the birthdate
     */
    public Date getBirthdate() {
        return birthdate;
    }

    /**
     * @param birthdate the birthdate to set
     */
    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    /**
     * @return the identifier
     */
    public String getIdentifier() {
        return identifier;
    }

    /**
     * @param identifier the identifier to set
     */
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    /**
     * @return the genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * @param genre the genre to set
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the salary
     */
    public long getSalary() {
        return salary;
    }

    /**
     * @param salary the salary to set
     */
    public void setSalary(long salary) {
        this.salary = salary;
    }

    /**
     * @return the identifier_type
     */
    public String getIdentifierType() {
        return identifierType;
    }

    /**
     * @param identifierType the identifierType to set
     */
    public void setIdentifierType(String identifierType) {
        this.identifierType = identifierType;
    }

}
