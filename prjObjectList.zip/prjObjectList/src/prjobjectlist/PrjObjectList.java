/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prjobjectlist;

import java.util.Date;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import pkgClasses.clsPerson;

/**
 *
 * @author jota
 */
public class PrjObjectList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int peopleAmount = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de personas."));
        LinkedList<clsPerson> list = new LinkedList<>();
        
        for (int i = 1; i <= peopleAmount; i++) {
            JOptionPane.showMessageDialog(null, "Solicitando información de la persona " + i);
            String name1 = JOptionPane.showInputDialog("Primer nombre de la persona " + i);
            String name2 = JOptionPane.showInputDialog("Segundo nombre de la persona " + i);
            String lastname1 = JOptionPane.showInputDialog("Primer apellido de la persona " + i);
            String lastname2 = JOptionPane.showInputDialog("Segundo nombre de la persona " + i);
            Date birthdate = new Date(JOptionPane.showInputDialog("Fecha de nacimiento " + i));
            String identifier = JOptionPane.showInputDialog("Documento de identificación de la persona " + i);
            String genre = JOptionPane.showInputDialog("Género de la persona " + i);
            String phone = JOptionPane.showInputDialog("Teléfono de la persona " + i);
            String email = JOptionPane.showInputDialog("Dirección de correo nombre de la persona " + i);
            long salary = Long.parseLong(JOptionPane.showInputDialog("Dirección de correo nombre de la persona " + i));
            String identifierType = "";
            
            clsPerson p = new clsPerson(name1, name2, lastname1, lastname2, birthdate, identifier, genre, phone, email, salary, identifierType);
            list.add(p);
        }
        
        System.out.println("Cantidad de personas almacenadas en la lista: " + list.size());
        
        long sum = 0;
        for (int i = 0; i < list.size(); i++) {
            clsPerson p = list.get(i);
            sum += p.getSalary();
        }
        float avg = sum / list.size();
        System.out.println("Promedio de salarios: " + avg);
        
        
        String report = "";
        for (clsPerson p : list) {
            report += p.getName1() + " " + p.getName2() + " " + p.getLastname1() + " " + p.getLastname2() + "\t" + p.getIdentifier() + "\t" + p.CalcularImpuestos();
            report += "\n";
        }
       
        System.out.println(report);
    }
    
}
