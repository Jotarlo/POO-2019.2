/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgModelo;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.stream.Stream;
import javax.swing.JOptionPane;
import pkgClases.clsInmueble;

/**
 *
 * @author jota
 */
public class ModeloInmueble {

    private final String rutaArchivo = "data/inmuebles.csv";

    public ModeloInmueble() {
    }

    public LinkedList<clsInmueble> obtenerInmuebles() {
        LinkedList<clsInmueble> lista = new LinkedList<>();
        try (
                Stream<String> stream = Files.lines(Paths.get(rutaArchivo))) {
            stream.forEach((info) -> {
                String[] i = info.split(",");
                int id = Integer.parseInt(i[0]);
                String dir = i[1];
                String desc = i[5];
                String tipo = i[2];
                long val = Long.parseLong(i[3]);
                int mt = Integer.parseInt(i[4]);
                lista.add(new clsInmueble(id, dir, desc, tipo, val, mt));
            });
            return lista;
        } catch (IOException e) {
            return null;
        }
    }
    
    
    public Boolean guardarInmuebles(LinkedList<clsInmueble> lista){
        try {
            LinkedList<String> lineas = new LinkedList<>();
            for (clsInmueble i : lista) {
                String linea = i.getId() + "," + i.getDireccion() + "," + i.getTipo() + "," + i.getValor() + "," + i.getMetros() + "," + i.getDescripcion();
                lineas.add(linea);
            }
            Path file = Paths.get(rutaArchivo);
            Files.write(file, lineas, StandardCharsets.UTF_8);
            return true;
        } catch (IOException ex) {
            return false;
        }
    }
}
