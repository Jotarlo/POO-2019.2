/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgClases;

/**
 *
 * @author jota
 */
public class clsInmueble {
    private int id;
    private String direccion;
    private String descripcion;
    private String tipo;
    private long valor;
    private int metros;

    public clsInmueble() {
    }

    public clsInmueble(int id, String direccion, String descripcion, String tipo, long valor, int metros) {
        this.id = id;
        this.direccion = direccion;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.valor = valor;
        this.metros = metros;
    }

       
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the direccion to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    /**
     * @return the valor
     */
    public long getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(long valor) {
        this.valor = valor;
    }

    /**
     * @return the metros
     */
    public int getMetros() {
        return metros;
    }

    /**
     * @param metros the metros to set
     */
    public void setMetros(int metros) {
        this.metros = metros;
    }
}
