/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgControlador;

import java.util.LinkedList;
import pkgClases.clsInmueble;
import pkgModelo.ModeloInmueble;

/**
 *
 * @author jota
 */
public class ControladorInmueble {

    private ModeloInmueble modelo;
    
    public ControladorInmueble() {
        this.modelo = new ModeloInmueble();
    }
    
    public LinkedList<clsInmueble> obtenerListaDeInmuebles(){
        return this.modelo.obtenerInmuebles();
    }
    
    public Boolean guardarInmuebles(LinkedList<clsInmueble> lista){
        return this.modelo.guardarInmuebles(lista);
    }
    
}
